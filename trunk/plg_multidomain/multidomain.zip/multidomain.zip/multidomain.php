<?php
/**
 * @package    Tuneups
 * @subpackage System.Multidomain
 * @copyright  (c) 2011 WebMechanic.biz
 * @version    0.1.0 - 29.10.2011
 */

// check global access point
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * MultiDomain Switcher
 * @return void
 */
class plgSystemMultiDomain extends JPlugin
{

	/**
	 * Ermittelt den aktuellen Hostnamen aus dem Request und legt ggf.
	 * ein anderes Menü und Template für den Aufruf fest.
	 */
	public function onAfterInitialise()
	{
		$app = JFactory::getApplication();

		// frontend check
		if (!$app->isSite()) {
			return true;
		}

		// a quick check if there's anything to do at all...
		$proceed = false;
		for ($d = 1; $d <= 3; $d++) {
			$proceed = $proceed || $this->params->get('enabled' . $d, 0);
		}
		// nope.
		if (!$proceed) return true;

		$config = JFactory::getConfig();
		$uri    = JFactory::getURI();
		$menu   = $app->getMenu('site');

		$host   = strtolower($uri->getHost());
		// allow 'www' wildcard?
		$www    = (bool)$this->params->get('wildcard', false) ? 'www.' : '';

		for ($d = 1; $d <= 3; $d++)
		{
			// is this of interest?
			if (false == (bool) $this->params->get('enabled' . $d, 0)) {
				continue;
			}

			$domainX = strtolower($this->params->get('domain' . $d));
			// match?
			if ($host == $domainX) {
				$domain = $domainX;
			}
			else if ($host == $www . $domainX) {
				$domain = $domainX;
			}
			else {
				continue;
			}

			// finally... the menu item id and template style id
			$itemid  = (int) $this->params->get('menu' . $d, 0);
			$tmpl    = (int) $this->params->get('tmpl' . $d, 0);
			break;
		}

		// set (another) default menu id in "shut-up" mode
		$item  = $menu->getDefault();
		if (isset($itemid) && $itemid != @$item->id) {
			// set template style
			$nuitem = $menu->getItem($itemid);
			$nuitem->template_style_id = $tmpl;
			// make new default
			$menu->setDefault($nuitem->id, $nuitem->language);
			$item = $menu->getDefault($nuitem->language);
		}

		// set live site and SSL according to menu item
		if (isset($domain)) {
			$host = ($item->params->get('secure')) ? 'https://' . $domain : 'http://' . $domain;
			$config->set('live_site', $host);

			// if there was a cookie domain set, update it
			if ($config->get('cookie_domain')) {
				$config->set('cookie_domain', $domain);
			}
		}
	}

}


<?php

/* SVN: $Id$ */

/**
 * @package joomla.plugin
 * @subpackage system.multidomain
 * @copyright Copyright (c) 2008 art-two [creative development]
 * @author Guido Essing [ecomeback] <ecomeback@os-development.de>
 * @version
 * 0.1 - 04.01.2009 - pre alpha<br />
 */

// check global access point
defined('_JEXEC') or exit( 'forbidden' );

$app = JFactory::getApplication();
$app->registerEvent( 'onAfterInitialise', 'plgSystemMultiDomain' );


/**
 * MultiDomain Switcher
 * @return void
 */
 function plgSystemMultiDomain()
 {
	$application =& JFactory::getApplication();
	// frontend check
	if (!$application->isSite()) {
		return true;
	}
	
	$config = JFactory::getConfig();
 	$uri 	= JFactory::getURI();
	$menu 	= JSite::getMenu();

	switch(strtolower($uri->getHost()))
	{
    case "central-getraenke.de";
        // set default menu id - home
        $menu->setDefault(21); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.central-getraenke.de');
        // set template
        JRequest::setVar('template', 'cg');
    break;
 
    case "www.central-getraenke.de";
        // set default menu id - home
        $menu->setDefault(21); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.central-getraenke.de');
        // set template
        JRequest::setVar('template', 'cg');
    break;
 
    case "brauerei-lang.de";
        // set default menu id - home
        $menu->setDefault(53); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.brauerei-lang.de');
        // set template
        JRequest::setVar('template', 'lang');
    break;
  
    case "www.brauerei-lang.de";
        // set default menu id - home
        $menu->setDefault(53); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.brauerei-lang.de');
        // set template
        JRequest::setVar('template', 'lang');
    break;
 
    case "braeustueble-waltershausen.de";
       // set default menu id - home
        $menu->setDefault(33); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.braeustueble-waltershausen.de');
        // set template
        JRequest::setVar('template', 'bs');
    break;
 
     case "www.braeustueble-waltershausen.de";
       // set default menu id - home
        $menu->setDefault(33); // id have to exists in #__menu
        // set live site
        $config->setValue('config.live_site', 'http://www.braeustueble-waltershausen.de');
        // set template
        JRequest::setVar('template', 'bs');
    break;
 
    default:
        // set default menu id - home
        //$menu->setDefault(1); // id have to exists in #__menu
        // set live site
        //$config->setValue('config.live_site', 'http://web6.hostrevolution.de');
        // set template
        //JRequest::setVar('template', 'cg');
    //break;
}
}
?>
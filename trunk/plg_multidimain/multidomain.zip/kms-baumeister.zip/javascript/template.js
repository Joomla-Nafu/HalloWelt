/**
 * @version SVN: $Id: header.php 18 2011-11-25 11:10:19Z elkuku $
 * @package    kms-baumeister
 * @subpackage Base
 * @author     K.-Michael Siebenlist {@link http://www.kms-net.de}
 * @author     Created on 25-Nov-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
